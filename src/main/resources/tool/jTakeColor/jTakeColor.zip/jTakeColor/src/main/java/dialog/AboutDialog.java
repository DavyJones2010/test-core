package dialog;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.Shell;

import ui.JTakeColor;

public class AboutDialog {
	public static void showAboutMessageBox() {
		Shell shell = JTakeColor.getTakeColorWindow().getShell();
		MessageBox messageBox = new MessageBox(shell, SWT.ICON_INFORMATION);
		messageBox.setText("Author");
		messageBox.setMessage("Copy Right CuteBen 1.0");
		messageBox.open();
	}
}
